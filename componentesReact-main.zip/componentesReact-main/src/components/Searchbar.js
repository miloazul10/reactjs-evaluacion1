import React from "react";

export default function SearchBar() {
  return <div className="searchbar">SearchBar</div>;
}
