import React from "react";

export default function Login() {
  return <div className="login">Login</div>;
}
